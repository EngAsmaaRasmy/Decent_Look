<?php

namespace App\Http\Controllers;

use App\Models\OrderChangeHistory;
use Illuminate\Http\Request;

class OrderChangeHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\OrderChangeHistory  $orderChangeHistory
     * @return \Illuminate\Http\Response
     */
    public function show(OrderChangeHistory $orderChangeHistory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\OrderChangeHistory  $orderChangeHistory
     * @return \Illuminate\Http\Response
     */
    public function edit(OrderChangeHistory $orderChangeHistory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\OrderChangeHistory  $orderChangeHistory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OrderChangeHistory $orderChangeHistory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OrderChangeHistory  $orderChangeHistory
     * @return \Illuminate\Http\Response
     */
    public function destroy(OrderChangeHistory $orderChangeHistory)
    {
        //
    }
}
